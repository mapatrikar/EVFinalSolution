
//import './Home.css';

import Banner from './components/ui/Banner';
import CardContainer from './components/ui/CardContainer';

import IconContainer from './components/ui/IconContainer';
function Home() {


    return (

        <div>
            <left><a href="../../src/modules/VehicalInfo/VehicalInfo.html">Vehical Info</a></left>
            <Banner />
           
            <CardContainer />
            <IconContainer />
            
        </div>
    );


}
export default Home;