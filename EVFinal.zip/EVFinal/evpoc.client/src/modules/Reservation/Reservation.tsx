import { useEffect } from 'react';
import './Reservation.css';

function Reservation() {
    useEffect(() => {
        const loadHtmlContent = async (url: RequestInfo | URL, containerId: string) => {
            try {
                const response = await fetch(url);
                const data = await response.text();
                const container = document.getElementById(containerId);
                if (container) {
                    container.innerHTML = data;

                    // Execute script tags
                    const scriptTags = container.getElementsByTagName('script');
                    for (let i = 0; i < scriptTags.length; i++) {
                        try {
                            // Create a new script element and set its content
                            const script = document.createElement('script');
                            script.textContent = scriptTags[i].textContent;
                            // Append the script to the document head to execute it
                            document.head.appendChild(script);
                            // Remove the script element after execution
                            document.head.removeChild(script);
                        } catch (error) {
                            console.error('Error executing script:', error);
                        }
                    }
                }
            } catch (error) {
                console.error('Error loading HTML content:', error);
            }
        };

        loadHtmlContent('/reservation.html', 'reservation-content');
    }, []);

    return (
        <div id="reservation-content">
            {/* Content from reservation.html will be loaded here */}
        </div>
    );
}

export default Reservation;
