/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-undef */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function showStations() {

     if (document.getElementById("timeslot").value !== "" && document.getElementById("inputdate").value !== "")
         {
          document.getElementById("loadericon").style.display="block";
          document.getElementById("stationList").hidden=true;
          setTimeout(() => {            
/*          document.body.style.background = "#E0F8FF";*/
     /*     document.getElementById("searchdiv").style.background = "url('EV st.jpg') no-repeat right top";*/
          document.getElementById("stationList").hidden=false;
          document.getElementById("loadericon").style.display="none";
          }, 1000);
          
        }

         else
         alert("Please select date/timeslot");
  }
  
  window.addEventListener("load", () => {
  
    document.getElementById("timeslot").addEventListener("change", setPrice);
  
    document.getElementById("ctype").addEventListener("change", typeFilter);

    document.getElementById("inputdate").addEventListener("change", function(){ document.getElementById("stationList").hidden=true;
    ldate = new Date(document.getElementById("inputdate").value);
    console.log("date",ldate.toDateString())
    document.getElementById("bookingdate").innerText = ldate.toDateString();
    });
  
  })
  
  function setPrice(e){    

    var timeslot = document.getElementById("timeslot");
    var text = timeslot.options[timeslot.selectedIndex].text;
    document.getElementById("bookingtime").innerText = text;

    if (e.target.value == "01"){  
    console.log("setprice1");
    document.getElementById("bookingrate").innerText = "12 NOK";
    }

    if (e.target.value == "02"){  
    console.log("setprice2");
    document.getElementById("bookingrate").innerText = "20 NOK";
    }

    if (e.target.value == "05"){  
    console.log("setprice3");
    document.getElementById("bookingrate").innerText = "30 NOK";
    }

    if (e.target.value == "06"){  
    console.log("setprice4");
    document.getElementById("bookingrate").innerText = "15 NOK";
    }
  
  }
  
  function typeFilter() {
    // Declare variables
    console.log("Type filter")
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("ctype");
    filter = input.value.toUpperCase();
    console.log("Type filter",filter)
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
  
    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }
  
  var span1 = document.getElementById("mdlclose1");
  span1.onclick = function() {
    console.log("close 1st modal")
    modal1 = document.getElementById('bookingpage');
    modal1.style.display = "none";
  }

  var span2 = document.getElementById("mdlclose2");
  span2.onclick = function() {
    console.log("close 2nd modal")
    modal2 = document.getElementById('infopage');
    modal2.style.display = "none";
  }
  
  var span3 = document.getElementById("mdlclose3");
  span3.onclick = function() {
    console.log("close 3rd modal")
    modal3 = document.getElementById('morefilter');
    modal3.style.display = "none";
  }

  function unCheckAll() {
    console.log("uncheck")
 
 let inputs = document.querySelectorAll('input[type=checkbox]');
console.log("count",inputs)
 for (let i = 0; i < inputs.length; i++) {
     inputs[i].checked = false;
 }
}