document.getElementById('check-availability-button').addEventListener('click', function () {
    const locationInput = document.getElementById('location-input').value.trim();
    const myLocation = document.getElementById('currentlocation');
    if (!locationInput && !myLocation.checked) {
        alert('Please enter a location or use your current location.');
    } else {
        document.getElementById('results-section').style.display = 'block';
    }
});

document.getElementById('book-button').addEventListener('click', function () {
    const selectedStation = document.querySelector('input[name="station"]:checked');

    if (selectedStation) {
        const row = selectedStation.closest('tr');
        const selectedService = row.querySelector('select').value;
        if (selectedService) {
            alert(`Booking confirmed for Station ${selectedStation.value} with service ${selectedService}`);
        } else {
            alert('Please select a service type.');
        }
    } else {
        alert('Please select a charging station.');
    }
});

document.getElementById('search-location-button').addEventListener('click', function () {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const googleMapsUrl = `https://www.google.com/maps?q=${lat},${lng}`;
            window.open(googleMapsUrl, '_blank');
            document.getElementById('location-input').value = `Lat: ${lat}, Lng: ${lng}`;
            document.getElementById('results-section').style.display = 'block';
        }, function (error) {
            alert("Error getting location: " + error.message);
        });
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});