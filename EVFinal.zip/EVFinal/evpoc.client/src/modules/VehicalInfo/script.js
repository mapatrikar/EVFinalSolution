<script src="script.js">
document.addEventListener('DOMContentLoaded', () => {
        console.log("Cards loaded successfully");
});

</script>