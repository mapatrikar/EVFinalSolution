import React from 'react';

const Sidebar: React.FC = () => {
    return (
        <div className="sidebar">
            <ul>
                <li>Option 1
                    <ul>
                        <li>@</li>
                        <li>b</li>
                    </ul>
                </li>
                <li>Option 2</li>
                <li>Option 3</li>
                <li>Option 42</li>
                <li>Option 6</li>
                <li>Option 7</li>
                <li>Option 8</li>
                <li>Option 9</li>
            </ul>
        </div>
    );
};

export default Sidebar;
