import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="header">
            Dashboard Header
        </header>
    );
};

export default Header;
