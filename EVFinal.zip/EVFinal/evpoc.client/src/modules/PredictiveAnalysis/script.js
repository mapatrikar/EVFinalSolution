/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-unused-vars */
// Simulated real-time data
<script>
setInterval(function() {
    document.getElementById("current-status").innerText = Math.random() > 0.5 ? "Charging" : "Not Charging";
    document.getElementById("current-speed").innerText = Math.floor(Math.random() * 100) + " kW";
    document.getElementById("availability-info").innerText = Math.random() > 0.5 ? "Available" : "Occupied";
}, 3000); 


const dailyStatusData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [{
        label: 'Usage Status',
        data: [30, 45, 50, 35, 60, 55, 40], // Sample data for demonstration
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1
    }]
};

// Chart configuration
const dailyStatusConfig = {
    type: 'bar',
    data: dailyStatusData,
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
};


const dailyStatusChart = new Chart(document.getElementById('daily-status-chart'), dailyStatusConfig);
</script>
