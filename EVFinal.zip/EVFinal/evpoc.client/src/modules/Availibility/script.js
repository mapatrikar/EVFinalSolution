<script>
	function selectLocation(location) {
		
		if(location=='ChargingStation1'){
            var popup = document.getElementById("popupavail");


	// Get the link that opens the modal
	var openLink = document.getElementById("openPopup");
	popup.style.display = "block";
			
		} else if(location=='ChargingStation2'){
            var popup = document.getElementById("popupunavail");


	// Get the link that opens the modal
	var openLink = document.getElementById("openPopup");
	popup.style.display = "block";
			
		}
			
			
        }

	function closeAvail(){
		popupavail.style.display = "none";
			
		}

	function closeUnavail(){
		popupunavail.style.display = "none";
			
		}


	function success(){
		alert('Booking completed successfully.');
			
		}

	// script.js

	// Get the modal
	var popup = document.getElementById("popup");


	// Get the link that opens the modal
	var openLink = document.getElementById("openPopup");
	var openLink1 = document.getElementById("openPopup1");
	var openLink2 = document.getElementById("openPopup2");


	// Get the link that closes the modal
	var closeLink = document.getElementsByClassName("close-btn")[0];

	// When the user clicks the link, open the modal 
	openLink.onclick = function(event) {
		event.preventDefault();

	popup.style.display = "block";
	content1.style.display = "block";
	content2.style.display = "none";
	content3.style.display = "none";
		}

	openLink2.onclick = function(event) {
		event.preventDefault();

	popup.style.display = "block";
	content1.style.display = "none";
	content2.style.display = "none";
	content3.style.display = "block";
		}

	openLink1.onclick = function(event) {
		event.preventDefault();

	popup.style.display = "block";
	content1.style.display = "none";
	content2.style.display = "block";
	content3.style.display = "none";
		}

	// When the user clicks on the close link, close the modal
	closeLink.onclick = function(event) {
		event.preventDefault();
	popup.style.display = "none";
		  
		}

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		  if (event.target == popup) {
		popup.style.display = "none";
			
			
		  }
		}


</script>