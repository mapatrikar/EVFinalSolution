import React, { useState } from 'react';
import Feature from './modules/Availibility/Feature';
import './components/ui/Menubar.css';
import Reservation from './modules/Reservation/Reservation.tsx';
import DCCharger from './modules/DCCharger/DCCharger';
import PredictiveAnalysis from './modules/PredictiveAnalysis/PredictiveAnalysis';
/*import AppAdmin from './AppAdmin';*/
import Dashboard from './modules/AppAdmin/Dashboard';
import Home from './Home';

const App: React.FC = () => {
    const [selectedMenu, setSelectedMenu] = useState<string>('Home');
    const [userRole, setUserRole] = useState<string>('User');

    const handleMenuClick = (menu: string) => {
        setSelectedMenu(menu);
    };

    const handleRoleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const role = event.target.value;
        setUserRole(role);
        if (role === 'Admin/CS Owner') {
            setSelectedMenu('AppAdmin');
        } else {
            setSelectedMenu('Home');
        }
    };

    return (
        <div>
            <nav>
                <ul className="menubar">
                    <h1 onClick={() => handleMenuClick('Home')} className="logo">
                        <img src="./assets/logo.png" height="50px"  />
                    </h1>
                    {userRole !== 'Admin/CS Owner' && (
                        <>
                            <li onClick={() => handleMenuClick('Reservation')}>
                                <button>Reservation</button>
                            </li>
                            <li onClick={() => handleMenuClick('DCCharger')}>
                                <button>DC Charging</button>
                            </li>
                            <li onClick={() => handleMenuClick('Feature')}>
                                <button>Availability</button>
                            </li>
                            <li onClick={() => handleMenuClick('PredictiveAnalysis')}>
                                <button>Predictive Analysis</button>
                            </li>
                        </>
                    )}
                    <div className="dropdown">
                        Sign In
                        <select name="login" id="login" value={userRole} onChange={handleRoleChange}>
                            <option value="User">Customer</option>
                            <option value="Admin/CS Owner">Admin/CS Owner</option>
                        </select>
                    </div>
                </ul>
            </nav>
            {selectedMenu === 'Home' && <Home />}
            {selectedMenu === 'Reservation' && <Reservation />}
            {selectedMenu === 'Feature' && <Feature />}
            {selectedMenu === 'DCCharger' && <DCCharger />}
            {selectedMenu === 'PredictiveAnalysis' && <PredictiveAnalysis />}
            {selectedMenu === 'AppAdmin' && <Dashboard />}
        </div>
    );
};

export default App;
