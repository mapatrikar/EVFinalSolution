import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCopyright } from '@fortawesome/free-solid-svg-icons';

const Footer: React.FC = () => {
  return (
    <footer style={{ backgroundColor: '#000000', color: '#7fff00', padding: '10px'  }}>
      <p>
        <FontAwesomeIcon icon={faCopyright}/>
        {' '}
        <span style={{ color: '#888' }}>2024 TCS. All rights reserved.</span>
      </p>
    </footer>
  );
};

export default Footer;
