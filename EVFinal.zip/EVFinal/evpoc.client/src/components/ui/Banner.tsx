
import React from 'react';
import './Banner.css';
/*import { BsEvStation } from "react-icons/bs";*/
import { IoPricetagsOutline } from "react-icons/io5";
import { MdOutlineSubscriptions } from "react-icons/md";
import { FaComments } from "react-icons/fa";

const Banner = () => {
    return (
        <div className="banner">
           
           {/* <h1><BsEvStation /></h1>*/}
            <div className="button-container">
                <h1>Electric Charge Innovator</h1><br></br>
                <b>Experience the Excellence</b><br></br>

                <button className="find-button">Suscribe Now</button>
            </div>
            <div className="cards-container">
                <div className="card">
                    <div className="icon ev-charging"><h1><b><IoPricetagsOutline /></b></h1></div>
                    <p className="card-text">Dynamic Pricing and Rewards</p>
                </div>
                <div className="card">
                    <div className="icon petrol-pump"><h1><b><MdOutlineSubscriptions /></b></h1></div>
                    <p className="card-text"><li>Predective Analysis</li></p>
                </div>
                <div className="card">
                    <div className="icon roadmap"><h1><b><FaComments /></b></h1></div>
                    <p className="card-text">EV Owner Communities</p>
                </div>
            </div>
            <div className="moving-text-container">
                <p className="moving-text">Discover Nearby Stations</p>
            </div>
        </div>
    );
};

export default Banner;
