import React from 'react';
//import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
//import { faBatteryFull, faCar, faChargingStation, faGasPump, faMapMarkerAlt, faTools, faUser, faInfoCircle, faQuestionCircle, faCogs } from '@fortawesome/free-solid-svg-icons';
import './IconContainer.css';
import { FaChevronCircleRight } from "react-icons/fa";
import VehicalInfo from '../../modules/VehicalInfo/VehicalInfo.tsx';

const IconContainer: React.FC = () => {
    return (
        <div className="icon-container">
            <center><h2>Additonal Feature</h2></center>
            {/*<div className="icon-row">*/}
            {/*    <FaChevronCircleRight />*/}
            {/*     News & Event*/}
            {/*    <FaChevronCircleRight />*/}
            {/*    Dynamic Pricing*/}
            {/*    <FaChevronCircleRight />*/}
            {/*    Rewards*/}
            {/*    <FaChevronCircleRight />*/}
            {/*    Subscriptions*/}
            {/*    <FaChevronCircleRight />*/}
            {/*    Track your Location*/}
            {/*</div>*/}
            <div className="icon-row">
                <FaChevronCircleRight />
                Maintannace
                <FaChevronCircleRight />
                Ev Owner Comunities
                <FaChevronCircleRight />
                Help
                <FaChevronCircleRight />
                About Us
                <FaChevronCircleRight />
                Contact Us
            </div>
        </div>
    );
};

export default IconContainer;
