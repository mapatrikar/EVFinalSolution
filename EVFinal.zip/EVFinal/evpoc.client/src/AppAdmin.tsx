import React from 'react';
import Sidebar from './modules/AppAdmin/Sidebar.tsx';
import Header from './modules/AppAdmin/Header.tsx';
import Footer from './modules/AppAdmin/Footer.tsx';
import MainContent from 'C:/Users/MadhurPatrikar/Documents/EVFinal/evpoc.client/src/modules/AppAdmin/MainContent.tsx';
import './AppAdmin.css';

const AppAdmin: React.FC = () => {
    return (
        <div className="AppAdmin">
            <Sidebar />
            <div className="main-section">
                <Header />
                <MainContent />
                <Footer />
            </div>
        </div>
    );
};

export default AppAdmin;
